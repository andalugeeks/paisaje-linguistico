export const environment = {
  production: true,
  backend_url: 'https://tuxpiper.api.ushahidi.io/',
  api_v3: 'api/v3/',
  api_v5: 'api/v5/',
  mapbox_api_key:
    'pk.eyJ1IjoidXNoYWhpZGkiLCJhIjoiY2lxaXUzeHBvMDdndmZ0bmVmOWoyMzN6NiJ9.CX56ZmZJv0aUsxvH5huJBw', // Default OSS mapbox api key
  default_locale: 'en_US',
  oauth_client_id: 'ushahidiui',
  oauth_client_secret: '35e7f0bca957836d05ca0492211b0ac707671261',
};
