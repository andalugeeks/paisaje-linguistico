export { PostDetailsModalComponent } from './post-details-modal/post-details-modal.component';
