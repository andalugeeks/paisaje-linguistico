export const ENVS = {
  dev: 'http://localhost:4200',
  staging: 'https://mzima.staging.ush.zone',
};
