const loginData = {
  login: 'konstantin@test.com',
  password: 'trausertra324',
};

const roleData = {
  name: 'Automated Role',
  description: 'Automated Role Description',
  permissions: 'Manage Posts',
};

export default {
  loginData,
  roleData,
};
