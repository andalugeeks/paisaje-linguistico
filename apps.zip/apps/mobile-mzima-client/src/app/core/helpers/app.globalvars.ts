export class GlobalService {
  public static globalVariable: string = '';
  public static lsSpellingProposal: string = 'spellingProposal';
}
