export interface DateRangeFormat {
  from: string | null;
  to: string | null;
}
