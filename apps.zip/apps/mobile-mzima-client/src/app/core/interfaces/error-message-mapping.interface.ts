export interface ErrorMessageMapping {
  [key: string]: { [key: string]: { [key: string]: string } };
}
