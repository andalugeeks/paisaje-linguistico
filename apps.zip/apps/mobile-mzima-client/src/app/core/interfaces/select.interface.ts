export interface SelectOptionInterface {
  label: string;
  value: any;
}
