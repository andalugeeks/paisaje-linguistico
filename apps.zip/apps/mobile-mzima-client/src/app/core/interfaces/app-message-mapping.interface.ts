export interface AppMessageMapping {
  [key: string]: { [key: string]: string };
}
