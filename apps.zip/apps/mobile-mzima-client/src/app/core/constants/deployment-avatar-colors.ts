export const deploymentAvatarColors = [
  '#3E54A3',
  '#70A731',
  '#326D1D',
  '#F2984F',
  '#BD544E',
  '#9E84D3',
  '#6142A5',
  '#CB559C',
  '#FF9A99',
];
