export { SharedModule } from './shared.module';
export { PipeModule } from './pipe.module';
